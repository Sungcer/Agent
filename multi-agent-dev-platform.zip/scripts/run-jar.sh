#!/usr/bin/env bash
set -e
java -jar target/multi-agent-dev-platform-1.0.0.jar
