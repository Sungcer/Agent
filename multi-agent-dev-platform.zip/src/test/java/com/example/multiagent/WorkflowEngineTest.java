package com.example.multiagent;

import com.example.multiagent.dto.ProjectRequest;
import com.example.multiagent.dto.WorkflowResult;
import com.example.multiagent.engine.WorkflowEngine;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class WorkflowEngineTest {
    @Autowired
    private WorkflowEngine workflowEngine;

    @Test
    void runWorkflowShouldGenerateFiles() throws Exception {
        ProjectRequest request = new ProjectRequest();
        request.setProjectName("demo-test");
        request.setDescription("测试多Agent生成项目");
        WorkflowResult result = workflowEngine.run(request);
        assertTrue(result.isSuccess());
        assertFalse(result.getMessages().isEmpty());
        assertFalse(result.getGeneratedFiles().isEmpty());
    }
}
