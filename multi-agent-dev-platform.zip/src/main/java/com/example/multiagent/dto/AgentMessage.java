package com.example.multiagent.dto;

import java.time.LocalDateTime;

public class AgentMessage {
    private String agentName;
    private String stage;
    private String content;
    private LocalDateTime time = LocalDateTime.now();

    public AgentMessage() {}
    public AgentMessage(String agentName, String stage, String content) {
        this.agentName = agentName;
        this.stage = stage;
        this.content = content;
    }
    public String getAgentName() { return agentName; }
    public void setAgentName(String agentName) { this.agentName = agentName; }
    public String getStage() { return stage; }
    public void setStage(String stage) { this.stage = stage; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public LocalDateTime getTime() { return time; }
    public void setTime(LocalDateTime time) { this.time = time; }
}
