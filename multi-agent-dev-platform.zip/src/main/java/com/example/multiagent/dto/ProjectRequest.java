package com.example.multiagent.dto;

import jakarta.validation.constraints.NotBlank;

public class ProjectRequest {
    @NotBlank(message = "项目名称不能为空")
    private String projectName;
    @NotBlank(message = "项目描述不能为空")
    private String description;
    private String techStack = "Spring Boot + Thymeleaf";
    private boolean generateDemoCode = true;

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getTechStack() { return techStack; }
    public void setTechStack(String techStack) { this.techStack = techStack; }
    public boolean isGenerateDemoCode() { return generateDemoCode; }
    public void setGenerateDemoCode(boolean generateDemoCode) { this.generateDemoCode = generateDemoCode; }
}
