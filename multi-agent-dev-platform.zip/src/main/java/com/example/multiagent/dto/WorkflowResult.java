package com.example.multiagent.dto;

import java.util.ArrayList;
import java.util.List;

public class WorkflowResult {
    private String workflowId;
    private String projectName;
    private String workspacePath;
    private List<AgentMessage> messages = new ArrayList<>();
    private List<String> generatedFiles = new ArrayList<>();
    private boolean success;

    public String getWorkflowId() { return workflowId; }
    public void setWorkflowId(String workflowId) { this.workflowId = workflowId; }
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }
    public String getWorkspacePath() { return workspacePath; }
    public void setWorkspacePath(String workspacePath) { this.workspacePath = workspacePath; }
    public List<AgentMessage> getMessages() { return messages; }
    public void setMessages(List<AgentMessage> messages) { this.messages = messages; }
    public List<String> getGeneratedFiles() { return generatedFiles; }
    public void setGeneratedFiles(List<String> generatedFiles) { this.generatedFiles = generatedFiles; }
    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }
}
