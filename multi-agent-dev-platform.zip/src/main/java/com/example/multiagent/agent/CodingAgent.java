package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import com.example.multiagent.storage.FileWriterService;
import org.springframework.stereotype.Component;

@Component
public class CodingAgent implements DevAgent {
    private final FileWriterService fileWriter;
    public CodingAgent(FileWriterService fileWriter) { this.fileWriter = fileWriter; }
    public String name() { return "代码生成Agent"; }
    public String stage() { return "编写代码"; }
    public void execute(WorkflowContext ctx) throws Exception {
        String base = sanitize(ctx.request().getProjectName());
        fileWriter.write(ctx, base + "/README.md", "# " + ctx.request().getProjectName() + "\n\n" + ctx.request().getDescription() + "\n\n## 运行\n\n```bash\nmvn spring-boot:run\n```\n");
        fileWriter.write(ctx, base + "/pom.xml", pom(base));
        fileWriter.write(ctx, base + "/src/main/java/demo/DemoApplication.java", app());
        fileWriter.write(ctx, base + "/src/main/java/demo/controller/HelloController.java", controller());
        fileWriter.write(ctx, base + "/src/main/resources/application.yml", "server:\n  port: 8090\n");
        ctx.log(name(), stage(), "已生成一个可运行的 Spring Boot 示例子项目。" );
    }
    private String sanitize(String s) { return s == null ? "demo-project" : s.replaceAll("[^a-zA-Z0-9_-]", "-").toLowerCase(); }
    private String pom(String name) { return """
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
              <modelVersion>4.0.0</modelVersion>
              <parent><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-parent</artifactId><version>3.3.5</version></parent>
              <groupId>demo</groupId><artifactId>%s</artifactId><version>1.0.0</version>
              <properties><java.version>17</java.version></properties>
              <dependencies><dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-web</artifactId></dependency><dependency><groupId>org.springframework.boot</groupId><artifactId>spring-boot-starter-test</artifactId><scope>test</scope></dependency></dependencies>
            </project>
            """.formatted(name); }
    private String app() { return """
            package demo;
            import org.springframework.boot.SpringApplication;
            import org.springframework.boot.autoconfigure.SpringBootApplication;
            @SpringBootApplication
            public class DemoApplication { public static void main(String[] args) { SpringApplication.run(DemoApplication.class, args); } }
            """; }
    private String controller() { return """
            package demo.controller;
            import org.springframework.web.bind.annotation.GetMapping;
            import org.springframework.web.bind.annotation.RestController;
            import java.util.Map;
            @RestController
            public class HelloController {
                @GetMapping("/api/hello")
                public Map<String, Object> hello() { return Map.of("code", 200, "message", "hello multi-agent generated project"); }
            }
            """; }
}
