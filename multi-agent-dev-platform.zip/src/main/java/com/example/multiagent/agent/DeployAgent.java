package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import com.example.multiagent.storage.FileWriterService;
import org.springframework.stereotype.Component;

@Component
public class DeployAgent implements DevAgent {
    private final FileWriterService fileWriter;
    public DeployAgent(FileWriterService fileWriter) { this.fileWriter = fileWriter; }
    public String name() { return "部署Agent"; }
    public String stage() { return "部署"; }
    public void execute(WorkflowContext ctx) throws Exception {
        String base = ctx.request().getProjectName().replaceAll("[^a-zA-Z0-9_-]", "-").toLowerCase();
        fileWriter.write(ctx, base + "/Dockerfile", """
                FROM eclipse-temurin:17-jre
                WORKDIR /app
                COPY target/*.jar app.jar
                EXPOSE 8090
                ENTRYPOINT ["java", "-jar", "app.jar"]
                """);
        fileWriter.write(ctx, base + "/deploy.sh", """
                #!/usr/bin/env bash
                set -e
                mvn clean package -DskipTests
                docker build -t generated-demo:1.0.0 .
                docker run -d --name generated-demo -p 8090:8090 generated-demo:1.0.0
                """);
        ctx.log(name(), stage(), "已生成 Dockerfile 和 deploy.sh 部署脚本。" );
    }
}
