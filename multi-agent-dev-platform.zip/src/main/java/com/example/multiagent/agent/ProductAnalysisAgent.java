package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ProductAnalysisAgent implements DevAgent {
    public String name() { return "产品分析Agent"; }
    public String stage() { return "产品分析"; }
    public void execute(WorkflowContext ctx) {
        Map<String, Object> product = Map.of(
                "目标用户", "业务人员、项目经理、开发人员",
                "核心价值", "把一句业务想法转成可落地的软件原型",
                "功能模块", List.of("需求录入", "任务拆解", "代码生成", "测试生成", "部署脚本", "结果下载"),
                "项目描述", ctx.request().getDescription()
        );
        ctx.put("productAnalysis", product);
        ctx.log(name(), stage(), "完成产品定位、目标用户、核心模块和业务价值分析。" );
    }
}
