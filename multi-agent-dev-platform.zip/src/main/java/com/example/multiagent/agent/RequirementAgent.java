package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class RequirementAgent implements DevAgent {
    public String name() { return "需求分析Agent"; }
    public String stage() { return "需求分析"; }
    public void execute(WorkflowContext ctx) {
        Map<String, Object> req = Map.of(
                "功能需求", List.of("创建项目任务", "按Agent顺序执行", "保存过程日志", "生成项目文件", "提供下载接口"),
                "非功能需求", List.of("本地可运行", "Agent可插拔", "LLM客户端可替换", "生成结果可追踪"),
                "接口", List.of("POST /api/workflows/run", "GET /api/workflows/{id}", "GET /api/workflows/{id}/download")
        );
        ctx.put("requirements", req);
        ctx.log(name(), stage(), "完成需求拆解、接口清单、非功能需求定义。" );
    }
}
