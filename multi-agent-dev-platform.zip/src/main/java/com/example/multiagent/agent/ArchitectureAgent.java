package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ArchitectureAgent implements DevAgent {
    public String name() { return "架构设计Agent"; }
    public String stage() { return "架构设计"; }
    public void execute(WorkflowContext ctx) {
        Map<String, Object> arch = Map.of(
                "分层", List.of("Controller", "WorkflowEngine", "DevAgent", "LLM Client", "File Storage"),
                "执行链", "ProductAnalysis -> Requirement -> Architecture -> Coding -> Test -> Deploy",
                "扩展点", List.of("新增Agent实现DevAgent", "切换multi-agent.llm.mode", "替换FileWriterService为Git提交")
        );
        ctx.put("architecture", arch);
        ctx.log(name(), stage(), "完成系统分层、Agent执行链、扩展点设计。" );
    }
}
