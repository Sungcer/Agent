package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;
import com.example.multiagent.storage.FileWriterService;
import org.springframework.stereotype.Component;

@Component
public class TestAgent implements DevAgent {
    private final FileWriterService fileWriter;
    public TestAgent(FileWriterService fileWriter) { this.fileWriter = fileWriter; }
    public String name() { return "测试Agent"; }
    public String stage() { return "测试"; }
    public void execute(WorkflowContext ctx) throws Exception {
        String base = ctx.request().getProjectName().replaceAll("[^a-zA-Z0-9_-]", "-").toLowerCase();
        fileWriter.write(ctx, base + "/src/test/java/demo/HelloControllerTest.java", """
                package demo;
                import org.junit.jupiter.api.Test;
                import org.springframework.boot.test.context.SpringBootTest;
                @SpringBootTest
                class HelloControllerTest {
                    @Test void contextLoads() {}
                }
                """);
        fileWriter.write(ctx, base + "/TEST_PLAN.md", """
                # 测试计划
                1. 单元测试：Controller、Service、工具类。
                2. 集成测试：接口返回结构、异常分支。
                3. 部署验证：启动后访问 /api/hello。
                4. 回归测试：每次Agent生成代码后执行 mvn test。
                """);
        ctx.log(name(), stage(), "已生成测试类和测试计划。" );
    }
}
