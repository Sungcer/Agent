package com.example.multiagent.agent;

import com.example.multiagent.engine.WorkflowContext;

public interface DevAgent {
    String name();
    String stage();
    void execute(WorkflowContext context) throws Exception;
}
