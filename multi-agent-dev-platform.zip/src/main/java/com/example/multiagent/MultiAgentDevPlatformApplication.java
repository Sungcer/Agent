package com.example.multiagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiAgentDevPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(MultiAgentDevPlatformApplication.class, args);
    }
}
