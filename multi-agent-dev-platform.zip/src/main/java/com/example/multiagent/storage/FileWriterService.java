package com.example.multiagent.storage;

import com.example.multiagent.engine.WorkflowContext;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class FileWriterService {
    public void write(WorkflowContext ctx, String relativePath, String content) throws IOException {
        Path file = ctx.workspace().resolve(relativePath);
        Files.createDirectories(file.getParent());
        Files.writeString(file, content, StandardCharsets.UTF_8);
        ctx.addFile(relativePath);
    }
}
