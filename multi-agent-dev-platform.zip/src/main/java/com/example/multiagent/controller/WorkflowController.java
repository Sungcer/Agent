package com.example.multiagent.controller;

import com.example.multiagent.dto.ProjectRequest;
import com.example.multiagent.dto.WorkflowResult;
import com.example.multiagent.engine.WorkflowEngine;
import com.example.multiagent.util.ZipUtil;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Map;

@Controller
public class WorkflowController {
    private final WorkflowEngine workflowEngine;
    public WorkflowController(WorkflowEngine workflowEngine) { this.workflowEngine = workflowEngine; }

    @GetMapping("/")
    public String index() { return "index"; }

    @PostMapping("/api/workflows/run")
    @ResponseBody
    public ResponseEntity<?> run(@Valid @RequestBody ProjectRequest request) {
        try {
            WorkflowResult result = workflowEngine.run(request);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("success", false, "message", e.getMessage()));
        }
    }

    @GetMapping("/api/workflows/{id}")
    @ResponseBody
    public ResponseEntity<?> get(@PathVariable String id) {
        WorkflowResult result = workflowEngine.get(id);
        if (result == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(result);
    }

    @GetMapping("/api/workflows/{id}/download")
    public void download(@PathVariable String id, HttpServletResponse response) throws Exception {
        Path workspace = workflowEngine.workspace(id);
        String filename = URLEncoder.encode("generated-" + id + ".zip", StandardCharsets.UTF_8);
        response.setContentType("application/zip");
        response.setHeader("Content-Disposition", "attachment; filename=" + filename);
        ZipUtil.zipDirectory(workspace, response.getOutputStream());
    }
}
