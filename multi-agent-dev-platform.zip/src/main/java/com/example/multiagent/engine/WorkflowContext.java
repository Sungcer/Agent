package com.example.multiagent.engine;

import com.example.multiagent.dto.AgentMessage;
import com.example.multiagent.dto.ProjectRequest;

import java.nio.file.Path;
import java.util.*;

public class WorkflowContext {
    private final String workflowId;
    private final ProjectRequest request;
    private final Path workspace;
    private final Map<String, Object> data = new LinkedHashMap<>();
    private final List<AgentMessage> messages = new ArrayList<>();
    private final List<String> generatedFiles = new ArrayList<>();

    public WorkflowContext(String workflowId, ProjectRequest request, Path workspace) {
        this.workflowId = workflowId;
        this.request = request;
        this.workspace = workspace;
    }
    public String workflowId() { return workflowId; }
    public ProjectRequest request() { return request; }
    public Path workspace() { return workspace; }
    public Map<String, Object> data() { return data; }
    public List<AgentMessage> messages() { return messages; }
    public List<String> generatedFiles() { return generatedFiles; }
    public void put(String key, Object value) { data.put(key, value); }
    @SuppressWarnings("unchecked")
    public <T> T get(String key, Class<T> type) { return (T) data.get(key); }
    public void log(String agent, String stage, String content) { messages.add(new AgentMessage(agent, stage, content)); }
    public void addFile(String relativePath) { generatedFiles.add(relativePath); }
}
