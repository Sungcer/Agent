package com.example.multiagent.engine;

import com.example.multiagent.agent.DevAgent;
import com.example.multiagent.dto.ProjectRequest;
import com.example.multiagent.dto.WorkflowResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WorkflowEngine {
    private final List<DevAgent> agents;
    private final Map<String, WorkflowResult> results = new ConcurrentHashMap<>();
    @Value("${multi-agent.workspace:./generated}")
    private String workspaceRoot;

    public WorkflowEngine(List<DevAgent> agents) {
        this.agents = agents.stream().sorted(Comparator.comparingInt(this::order)).toList();
    }

    public WorkflowResult run(ProjectRequest request) throws Exception {
        String id = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "-" + UUID.randomUUID().toString().substring(0, 8);
        Path workspace = Path.of(workspaceRoot).resolve(id);
        Files.createDirectories(workspace);
        WorkflowContext ctx = new WorkflowContext(id, request, workspace);
        for (DevAgent agent : agents) {
            agent.execute(ctx);
        }
        WorkflowResult result = new WorkflowResult();
        result.setWorkflowId(id);
        result.setProjectName(request.getProjectName());
        result.setWorkspacePath(workspace.toAbsolutePath().toString());
        result.setMessages(ctx.messages());
        result.setGeneratedFiles(ctx.generatedFiles());
        result.setSuccess(true);
        results.put(id, result);
        return result;
    }

    public WorkflowResult get(String id) { return results.get(id); }
    public Path workspace(String id) { return Path.of(workspaceRoot).resolve(id); }

    private int order(DevAgent agent) {
        return switch (agent.stage()) {
            case "产品分析" -> 1;
            case "需求分析" -> 2;
            case "架构设计" -> 3;
            case "编写代码" -> 4;
            case "测试" -> 5;
            case "部署" -> 6;
            default -> 99;
        };
    }
}
