package com.example.multiagent.llm;

public interface LlmClient {
    String generate(String systemPrompt, String userPrompt);
}
