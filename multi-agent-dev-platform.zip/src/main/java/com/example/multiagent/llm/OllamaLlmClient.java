package com.example.multiagent.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

@Component
@ConditionalOnProperty(prefix = "multi-agent.llm", name = "mode", havingValue = "ollama")
public class OllamaLlmClient implements LlmClient {
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newHttpClient();
    @Value("${multi-agent.llm.ollama-url}")
    private String ollamaUrl;
    @Value("${multi-agent.llm.ollama-model}")
    private String model;

    @Override
    public String generate(String systemPrompt, String userPrompt) {
        try {
            String prompt = systemPrompt + "\n\n用户需求：\n" + userPrompt;
            String body = mapper.writeValueAsString(Map.of("model", model, "prompt", prompt, "stream", false));
            HttpRequest request = HttpRequest.newBuilder(URI.create(ollamaUrl))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            JsonNode node = mapper.readTree(response.body());
            return node.path("response").asText(response.body());
        } catch (Exception e) {
            throw new RuntimeException("调用 Ollama 失败：" + e.getMessage(), e);
        }
    }
}
