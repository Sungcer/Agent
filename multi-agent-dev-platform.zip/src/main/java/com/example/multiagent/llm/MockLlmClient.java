package com.example.multiagent.llm;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "multi-agent.llm", name = "mode", havingValue = "mock", matchIfMissing = true)
public class MockLlmClient implements LlmClient {
    @Override
    public String generate(String systemPrompt, String userPrompt) {
        return "[MockLLM] " + systemPrompt + "\n" + userPrompt;
    }
}
